%Implement a region growing algorithm in a function that accepts an image and a (set of) seedpixel(s)
%as well as arguments that control the behaviour (neighborhood, homogeneity criteria, etc).
%Include a script that prompts the user to interactively select the seedpixels in an image. Then,
%create a figure that displays
%� original image
%� segmented image

clear all;

IM = rgb2gray(imread('PICS/buttons.png'));
[c, r, P] = impixel(IM);

segmentedImage = IM; 
imshow(segmentedImage, []);